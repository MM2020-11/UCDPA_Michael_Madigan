# UCDPA_Michael_Madigan
Repository for Certificate in Data Analytics for Business - Assignment Project &amp; Report - 2021

Report, code and data files included
